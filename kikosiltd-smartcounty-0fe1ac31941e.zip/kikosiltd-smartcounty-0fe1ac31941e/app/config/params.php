<?php

/**
 * stores the site's global params
 * @author Fredrick <mconyango@gmail.com>
 */
return array(
    'PHP_COMMAND' => 'php',
);
