<?php

/**
 * Email settings
 */
return array(
    'class' => 'ext.SwiftMailer.SwiftMailer',
);