#1.0.1
- Fixed actual bugs

#1.0.0
- Support Retina displays
- Removed fixed path to the cache
- Added method "flip"

#0.9.1
- Auto detect relative or absolute path for image
- Preload drivers by alias

#0.9
- Initial public release
