<?php

/**
 * Description of ParkingModuleController
 *
 * @author Fred <mconyango@gmail.com>
 */
class BizpermitModuleController extends Controller {

        const MENU_BIZ_PERMIT = 'BUSINESS_PERMIT';

        public function init()
        {
                parent::init();
        }

}
