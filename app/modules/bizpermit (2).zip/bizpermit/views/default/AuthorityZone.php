

<?php /**$this->setup_grid(
				'fee_schedule'=>array(
				'fields'=>'',
				'buttons'=>array(),
				'form'=>'fee_schedule'
				)
				)**/?>

<div>
	<form>
	</form>
</div>