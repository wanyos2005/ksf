<style type="text/css">
.tbl-form tr td{
	padding: 10px;
}
td{
	vertical-align:top;
}
</style>
<?=$js?>

<div class="widget-box">
											<div class="widget-header">
												<h4><?=$title?></h4>

												<span class="widget-toolbar">
													

													
												</span>
											</div>

											<div class="widget-body">
												<div class="widget-main">
													<div class="alert" style="display:none">
														<button data-dismiss="alert" class="close" type="button">
															<i class="icon-remove"></i>
														</button>
														<strong>
															<i class=""></i>
														</strong>
														<span>Change a few things up and try submitting again.</span><br/>
													</div>
													
												